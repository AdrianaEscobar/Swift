//: Playground - noun: a place where people can play

import UIKit

// Minireto

// Generar 100 números

/*
 Si el número es divisible entre 5, imprime: # el número  + “Bingo!!!”
 - Si el número es par, imprime: # el número + “par!!!”
 - Si el número es impar, imprime: # el número + “impar!!!”
 - Si el número se encuentra dentro de un rango del 30 al 40, imprime: # el número +  “Viva Swift!!!”
 Debes de usar la interpolación de variables para realizar la impresión de cada número.

*/

let numeros = 1...100

for num in numeros{
    
    if  num > 29 && num <= 40 {
        print("\(num) Viva Swift!!!!")
    } else if num%5 == 0 {print("\(num) Bingo!!!")} // número divisible entre 5
    else if num%2 == 0 {print("el número \(num) es par!!!")} // número par
    else if num%2 != 0 {print("el número \(num) es impar!!!")} // número impar

}